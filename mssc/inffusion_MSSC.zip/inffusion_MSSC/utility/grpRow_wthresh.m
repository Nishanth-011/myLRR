function v = grpRow_wthresh(b, lambda)

%%%%%%  b is z in the paper

[n, C] = size(b);
for i = 1:n    
        tmp = 1 - lambda/norm(b(i,:));
        tmp = (tmp + abs(tmp))/2;     %%%%  this functon is equavilent to max(tmp,0)
        v(i,:) = tmp*b(i,:);    
end
